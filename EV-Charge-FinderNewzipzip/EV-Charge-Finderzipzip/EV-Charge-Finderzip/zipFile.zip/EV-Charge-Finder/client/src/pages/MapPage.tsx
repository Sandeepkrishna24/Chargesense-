import { useEffect, useMemo, useState, useRef } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import MobileLayout from "@/components/layout/MobileLayout";
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import { MOCK_STATIONS, MOCK_VEHICLES, haversineDistance } from "@/lib/mockData";
import "leaflet/dist/leaflet.css";
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

// Helper component to update map view
function MapUpdater({ center, zoom }: { center: [number, number], zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
}

export default function MapPage() {
  const [location] = useLocation(); // Hook for location if needed, but we rely on window.location.search for params
  const userLat = 13.0067;
  const userLng = 80.2206;
  
  const [rangeLimit, setRangeLimit] = useState(20);

  // Parse query params
  const searchParams = new URLSearchParams(window.location.search);
  const stationId = searchParams.get('stationId');

  useEffect(() => {
    const savedRange = localStorage.getItem('userRange');
    if (savedRange) {
        setRangeLimit(Number(savedRange));
    }
  }, []);

  const vehicleId = localStorage.getItem('selectedVehicleId') || 'v1';
  const vehicle = MOCK_VEHICLES.find(x => x.id === vehicleId) || MOCK_VEHICLES[0];

  // STRICT MAP VISIBILITY RULE
  const visibleStations = useMemo(() => {
    return MOCK_STATIONS.filter(station => {
        // Always include selected station
        if (stationId && station.id === stationId) return true;

        // 1. Range Filter
        const dist = haversineDistance(userLat, userLng, station.latitude, station.longitude);
        if (dist > rangeLimit) return false;

        // 2. Compatibility Filter
        if (!vehicle.charger_type_supported.includes(station.charger_type)) return false;

        return true;
    });
  }, [rangeLimit, vehicle, stationId]);

  const selectedStation = useMemo(() => 
    stationId ? MOCK_STATIONS.find(s => s.id === stationId) : null
  , [stationId]);

  const mapCenter: [number, number] = selectedStation 
    ? [selectedStation.latitude, selectedStation.longitude] 
    : [userLat, userLng];
    
  const mapZoom = selectedStation ? 15 : 12;
  
  // Back button logic: if specific station selected, go back to recommendations
  const backHref = stationId ? "/recommendations" : "/home";

  const markerRefs = useRef<{[key: string]: L.Marker | null}>({});

  useEffect(() => {
    if (selectedStation && markerRefs.current[selectedStation.id]) {
      markerRefs.current[selectedStation.id]?.openPopup();
    }
  }, [selectedStation]);

  return (
    <MobileLayout>
      <div className="h-screen w-full relative">
        <div className="absolute top-4 left-4 z-[400]">
           <Link href={backHref}>
             <Button variant="secondary" size="icon" className="rounded-full shadow-xl bg-white text-black hover:bg-zinc-200">
               <ArrowLeft size={20} />
             </Button>
           </Link>
        </div>

        <div className="absolute top-4 right-4 z-[400] bg-black/80 backdrop-blur px-3 py-1 rounded-full text-xs font-mono text-primary border border-primary/20">
          Radius: {rangeLimit}km
        </div>

        <MapContainer 
          center={mapCenter} 
          zoom={mapZoom} 
          zoomControl={false}
          style={{ height: '100%', width: '100%', background: '#242424' }}
        >
          <MapUpdater center={mapCenter} zoom={mapZoom} />
          
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          />
          
          {/* User Marker & Range Circle */}
          <Marker position={[userLat, userLng]}>
            <Popup>You are here</Popup>
          </Marker>
          <Circle 
            center={[userLat, userLng]} 
            radius={rangeLimit * 1000} 
            pathOptions={{ color: '#ff8000', fillColor: '#ff8000', fillOpacity: 0.1 }} 
          />

          {/* Station Markers - Only Compatible & In-Range */}
          {visibleStations.map(station => (
            <Marker 
              key={station.id} 
              position={[station.latitude, station.longitude]}
              ref={el => { markerRefs.current[station.id] = el; }}
            >
              <Popup className="custom-popup">
                <div className="p-1 min-w-[150px]">
                  <h3 className="font-bold text-sm mb-1">{station.name}</h3>
                  <div className="flex justify-between items-center text-xs text-zinc-500 mb-2">
                     <span>{station.charger_type} {station.charger_power_kw}kW</span>
                     <span className={station.status === 'available' ? 'text-green-600' : 'text-orange-600'}>
                       {station.status}
                     </span>
                  </div>
                  <Button 
                    size="sm" 
                    className="w-full h-7 text-xs bg-primary text-black hover:bg-orange-400"
                    onClick={() => {
                       window.open(`https://www.google.com/maps/dir/?api=1&destination=${station.latitude},${station.longitude}`, '_blank');
                    }}
                  >
                    Navigate
                  </Button>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
    </MobileLayout>
  );
}
