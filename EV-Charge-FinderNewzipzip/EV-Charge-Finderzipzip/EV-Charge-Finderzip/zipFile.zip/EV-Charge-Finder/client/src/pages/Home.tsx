import { useState, useEffect } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Battery, Navigation, Zap, MapPin, ChevronRight, AlertCircle } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MOCK_VEHICLES, Vehicle } from "@/lib/mockData";
import MobileLayout from "@/components/layout/MobileLayout";
import { MapContainer, TileLayer, Marker, Circle } from 'react-leaflet';
import "leaflet/dist/leaflet.css";
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

export default function Home() {
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [soc, setSoc] = useState([45]); 
  const [rangeRadius, setRangeRadius] = useState([20]); 
  const [userProfile, setUserProfile] = useState({ name: '', email: '' });
  
  const userLat = 13.0067;
  const userLng = 80.2206;

  useEffect(() => {
    const vId = localStorage.getItem('selectedVehicleId') || 'v1';
    const v = MOCK_VEHICLES.find(x => x.id === vId) || MOCK_VEHICLES[0];
    setVehicle(v);
    
    // Initialize range from local storage if exists
    const savedRange = localStorage.getItem('userRange');
    if (savedRange) {
        setRangeRadius([parseInt(savedRange)]);
    }

    // Get user profile
    const name = localStorage.getItem('userName') || '';
    const email = localStorage.getItem('userEmail') || '';
    setUserProfile({ name, email });
  }, []);

  // Save range to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('userRange', rangeRadius[0].toString());
  }, [rangeRadius]);

  if (!vehicle) return null;

  const estimatedRange = Math.floor((vehicle.full_range_km * soc[0]) / 100);
  
  // Display name logic: Use name if available, else email, else "Driver"
  const displayName = userProfile.name || userProfile.email || "Driver";
  const displayInitial = displayName.charAt(0).toUpperCase();

  return (
    <MobileLayout>
      <div className="p-6 space-y-6">
        
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-zinc-400 text-sm font-medium">Welcome back,</h2>
            <h1 className="text-2xl font-bold truncate max-w-[200px]">{displayName}</h1>
          </div>
          <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center">
            <span className="font-bold text-primary">{displayInitial}</span>
          </div>
        </div>

        {/* Vehicle Status Card */}
        <div className="relative h-64 rounded-3xl overflow-hidden glass-card p-6 flex flex-col justify-between group">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-1">
               <span className="text-xs font-bold px-2 py-0.5 rounded bg-primary text-black">CONNECTED</span>
               <span className="text-xs text-zinc-400">{vehicle.name}</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-5xl font-mono font-bold tracking-tighter text-white">{soc[0]}</span>
              <span className="text-xl font-medium text-zinc-400">%</span>
            </div>
            <p className="text-zinc-400 text-sm mt-1">~{estimatedRange} km range remaining</p>
          </div>

          <div className="relative z-10 w-full">
             <div className="flex justify-between text-xs text-zinc-500 mb-2 font-medium tracking-wide">
               <span>SET BATTERY LEVEL</span>
               <span>{soc[0]}%</span>
             </div>
             <Slider 
               defaultValue={[45]} 
               max={100} 
               step={1} 
               value={soc}
               onValueChange={setSoc}
               className="cursor-pointer"
             />
          </div>

          <img 
            src={vehicle.image_url} 
            alt="Vehicle" 
            className="absolute -right-8 top-8 w-48 h-auto opacity-90 transition-transform duration-700 group-hover:scale-105"
          />
          
          <div className="absolute inset-0 bg-gradient-to-br from-zinc-900/90 via-zinc-900/50 to-primary/5 pointer-events-none" />
        </div>

        {/* Action Grid */}
        <div className="grid grid-cols-2 gap-4">
          <Link href={`/recommendations?range=${rangeRadius[0]}&soc=${soc[0]}`}>
             <Card className="p-4 bg-zinc-900/50 border-zinc-800 hover:border-primary/50 transition-colors cursor-pointer group">
               <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-3 group-hover:scale-110 transition-transform">
                 <Zap size={20} />
               </div>
               <div className="font-bold text-lg">Find Charger</div>
               <div className="text-xs text-zinc-500 mt-1">Best stations nearby</div>
             </Card>
          </Link>

          <Link href="/analytics">
             <Card className="p-4 bg-zinc-900/50 border-zinc-800 hover:border-secondary/50 transition-colors cursor-pointer group">
               <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center text-secondary mb-3 group-hover:scale-110 transition-transform">
                 <AlertCircle size={20} />
               </div>
               <div className="font-bold text-lg">Diagnostics</div>
               <div className="text-xs text-zinc-500 mt-1">Health check</div>
             </Card>
          </Link>
        </div>

        {/* Range Settings & Map Preview */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <MapPin size={18} className="text-primary" /> 
              Range Radius
            </h3>
            <span className="font-mono text-primary bg-primary/10 px-2 py-1 rounded text-sm">{rangeRadius[0]} km</span>
          </div>
          
          <Slider 
             defaultValue={[20]} 
             max={100} 
             step={5} 
             value={rangeRadius}
             onValueChange={setRangeRadius}
           />
           <p className="text-xs text-zinc-500">
             Searching for compatible {vehicle.charger_type_supported.join('/')} stations within {rangeRadius[0]}km.
           </p>

           <div className="h-40 rounded-xl overflow-hidden border border-zinc-800 relative grayscale hover:grayscale-0 transition-all">
             <div className="absolute inset-0 bg-zinc-800 flex items-center justify-center z-0">
                <MapContainer 
                  center={[userLat, userLng]} 
                  zoom={11} 
                  scrollWheelZoom={false} 
                  zoomControl={false} 
                  dragging={false} 
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                  />
                  {/* Updated color to Orange approx (hsl 30 100 50 -> #ff8000) */}
                  <Circle 
                    center={[userLat, userLng]} 
                    radius={rangeRadius[0] * 1000} 
                    pathOptions={{ color: '#ff8000', fillColor: '#ff8000', fillOpacity: 0.1 }} 
                  />
                  <Marker position={[userLat, userLng]} />
                </MapContainer>
             </div>
             <Link href="/map">
               <div className="absolute bottom-3 right-3 z-[400]">
                 <Button size="sm" className="bg-white text-black hover:bg-zinc-200 h-8 text-xs">
                   Expand Map
                 </Button>
               </div>
             </Link>
           </div>
        </div>

      </div>
    </MobileLayout>
  );
}
