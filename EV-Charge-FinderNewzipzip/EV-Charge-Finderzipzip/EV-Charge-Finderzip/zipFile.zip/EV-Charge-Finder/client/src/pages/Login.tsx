import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Zap, ArrowRight, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Mock auth delay
    setTimeout(() => {
      setIsLoading(false);
      if (email && password) {
        localStorage.setItem('userEmail', email);
        if (name) localStorage.setItem('userName', name);
        
        toast({
          title: "Welcome back!",
          description: "Syncing your vehicle data...",
        });
        setLocation("/vehicles");
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Please enter valid credentials.",
        });
      }
    }, 1500);
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-6 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-zinc-900 via-background to-background">
      <div className="w-full max-w-sm space-y-8">
        
        {/* Logo / Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-2"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary mb-4 border border-primary/20 shadow-[0_0_30px_-5px_rgba(0,255,157,0.3)]">
            <Zap size={32} fill="currentColor" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight font-sans">ChargeSense</h1>
          <p className="text-muted-foreground">Intelligent EV Charging</p>
        </motion.div>

        {/* Form */}
        <motion.form 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          onSubmit={handleLogin}
          className="space-y-4"
        >
          <div className="space-y-4">
            <div className="relative group">
              <Input 
                type="text" 
                placeholder="Name (Optional)" 
                className="h-12 bg-zinc-900/50 border-zinc-800 focus:border-primary/50 transition-all text-lg"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="relative group">
              <Input 
                type="email" 
                placeholder="Email address" 
                className="h-12 bg-zinc-900/50 border-zinc-800 focus:border-primary/50 transition-all text-lg"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="relative group">
              <Input 
                type="password" 
                placeholder="Password" 
                className="h-12 bg-zinc-900/50 border-zinc-800 focus:border-primary/50 transition-all text-lg"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full h-14 text-lg font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-all shadow-lg shadow-primary/20"
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="animate-pulse">Connecting...</span>
            ) : (
              <span className="flex items-center gap-2">Sign In <ArrowRight size={20} /></span>
            )}
          </Button>
        </motion.form>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center"
        >
          <a href="#" className="text-sm text-zinc-500 hover:text-primary transition-colors">
            Forgot your password?
          </a>
        </motion.div>
      </div>
    </div>
  );
}
