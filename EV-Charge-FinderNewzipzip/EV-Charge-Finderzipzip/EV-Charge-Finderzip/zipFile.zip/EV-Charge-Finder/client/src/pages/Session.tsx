import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import { BatteryCharging, Zap, Clock, Leaf, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import MobileLayout from "@/components/layout/MobileLayout";
import { Slider } from "@/components/ui/slider";

export default function Session() {
  const [, setLocation] = useLocation();
  const [progress, setProgress] = useState(0);
  const [kwh, setKwh] = useState(0);
  const [cost, setCost] = useState(0);
  const [time, setTime] = useState(0);

  // Simulate charging
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) return 100;
        return p + 0.5;
      });
      setKwh(k => k + 0.1);
      setCost(c => c + 1.5);
      setTime(t => t + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <MobileLayout showNav={false}>
      <div className="h-screen bg-black flex flex-col p-6 relative overflow-hidden">
        
        {/* Back Button */}
        <div className="absolute top-6 left-6 z-50">
          <Link href="/recommendations">
            <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/10">
              <ArrowLeft />
            </Button>
          </Link>
        </div>

        {/* Background Pulse (Orange) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl animate-pulse pointer-events-none" />

        <header className="relative z-10 text-center mb-8 pt-4 mt-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold tracking-wider animate-pulse border border-primary/20">
            <span className="w-2 h-2 rounded-full bg-primary" /> CHARGING ACTIVE
          </div>
          <h1 className="mt-4 text-xl font-bold">Ather Grid - Phoenix</h1>
          <p className="text-zinc-500 text-sm">DC Fast Charger • 50kW</p>
        </header>

        <div className="flex-1 flex flex-col items-center justify-center relative z-10">
          {/* Central Charging Ring */}
          <div className="relative w-64 h-64 flex items-center justify-center mb-12">
             {/* SVG Ring Background */}
             <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
               <circle cx="50" cy="50" r="45" fill="none" stroke="#333" strokeWidth="4" />
               <circle 
                 cx="50" cy="50" r="45" 
                 fill="none" 
                 stroke="#ff8000" /* Orange Hardcoded for SVG */
                 strokeWidth="4"
                 strokeDasharray="283"
                 strokeDashoffset={283 - (283 * progress) / 100}
                 strokeLinecap="round"
                 className="transition-all duration-1000 ease-linear"
               />
             </svg>
             
             <div className="text-center">
               <div className="text-6xl font-mono font-bold text-white tracking-tighter">
                 {Math.floor(progress)}<span className="text-2xl text-zinc-500">%</span>
               </div>
               <div className="text-primary font-bold mt-1 animate-pulse">
                 +24 kW
               </div>
             </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-6 w-full max-w-sm">
            <div className="text-center space-y-1">
              <div className="flex justify-center text-zinc-500"><Zap size={20} /></div>
              <div className="text-2xl font-mono font-bold">{kwh.toFixed(1)}</div>
              <div className="text-xs text-zinc-500 uppercase tracking-wider">kWh Added</div>
            </div>
            <div className="text-center space-y-1 border-x border-zinc-800">
              <div className="flex justify-center text-zinc-500"><Clock size={20} /></div>
              <div className="text-2xl font-mono font-bold">{formatTime(time)}</div>
              <div className="text-xs text-zinc-500 uppercase tracking-wider">Duration</div>
            </div>
            <div className="text-center space-y-1">
              <div className="flex justify-center text-zinc-500">₹</div>
              <div className="text-2xl font-mono font-bold">{cost.toFixed(0)}</div>
              <div className="text-xs text-zinc-500 uppercase tracking-wider">Cost</div>
            </div>
          </div>
        </div>

        {/* Action Slider */}
        <div className="mt-auto relative z-10 space-y-6">
           <div className="glass-card p-4 flex items-center justify-between">
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-full bg-green-900/20 flex items-center justify-center text-green-500">
                 <Leaf size={20} />
               </div>
               <div>
                 <div className="font-bold">{(kwh * 0.4).toFixed(2)} kg</div>
                 <div className="text-xs text-zinc-500">CO₂ Saved</div>
               </div>
             </div>
           </div>

           <Button 
             variant="destructive" 
             className="w-full h-14 text-lg font-bold rounded-xl"
             onClick={() => setLocation('/home')}
           >
             Stop Charging
           </Button>
        </div>

      </div>
    </MobileLayout>
  );
}
