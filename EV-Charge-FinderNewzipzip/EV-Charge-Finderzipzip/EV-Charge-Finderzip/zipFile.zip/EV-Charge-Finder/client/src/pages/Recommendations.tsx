import { useState, useMemo } from "react";
import { useLocation, Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Filter, Navigation, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import MobileLayout from "@/components/layout/MobileLayout";
import { MOCK_STATIONS, MOCK_VEHICLES, calculateChargeTime, haversineDistance } from "@/lib/mockData";
import { cn } from "@/lib/utils";

export default function Recommendations() {
  const [, setLocation] = useLocation();
  const [filterType, setFilterType] = useState<'all' | 'fast'>('all');

  const searchParams = new URLSearchParams(window.location.search);
  // Fallback to localStorage if URL param missing, or default 20
  const rangeLimit = Number(searchParams.get('range') || localStorage.getItem('userRange') || 20);
  const currentSoc = Number(searchParams.get('soc') || 45);

  const vehicleId = localStorage.getItem('selectedVehicleId') || 'v1';
  const vehicle = MOCK_VEHICLES.find(x => x.id === vehicleId) || MOCK_VEHICLES[0];

  const userLat = 13.0067;
  const userLng = 80.2206;

  // STRICT PIPELINE IMPLEMENTATION
  const recommendedStations = useMemo(() => {
    return MOCK_STATIONS
      .map(station => {
        // 1. Calculate Distance
        const dist = haversineDistance(userLat, userLng, station.latitude, station.longitude);
        
        // Calculate other metrics for display/ranking
        const chargeTime = calculateChargeTime(currentSoc, 80, vehicle.battery_capacity_kwh, station.charger_power_kw);
        const totalTime = chargeTime + station.queue_wait_minutes;
        
        // Simple score
        const score = (100 - (totalTime + dist)) + (station.reliability_score / 10);

        return { ...station, distance_km: dist, estimated_charge_time: chargeTime, total_time: totalTime, score };
      })
      // 2. Filter by Range Radius (Strict)
      .filter(s => s.distance_km <= rangeLimit) 
      // 3. Filter by Compatibility (Strict)
      .filter(s => vehicle.charger_type_supported.includes(s.charger_type))
      // 4. Rank
      .sort((a, b) => b.score - a.score);
  }, [rangeLimit, currentSoc, vehicle]);

  return (
    <MobileLayout showNav={false}>
      <div className="p-4 min-h-screen bg-black">
        
        {/* Header */}
        <header className="flex items-center justify-between mb-6 sticky top-0 bg-black/80 backdrop-blur-md z-50 py-2">
          {/* Explicit Back Link to previous logical screen (Home) */}
          <Link href="/home">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="text-white" />
            </Button>
          </Link>
          <h1 className="text-lg font-bold">Nearby Chargers</h1>
          <Button variant="ghost" size="icon" className="rounded-full">
            <Filter className="text-zinc-400" size={20} />
          </Button>
        </header>

        {/* Quick Filters */}
        <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-2">
           {['all', 'fast', 'available', 'cheapest'].map((f) => (
             <button
               key={f}
               onClick={() => setFilterType(f as any)}
               className={cn(
                 "px-4 py-2 rounded-full text-xs font-medium border whitespace-nowrap transition-all",
                 filterType === f 
                   ? "bg-primary text-black border-primary" 
                   : "bg-zinc-900 border-zinc-800 text-zinc-400"
               )}
             >
               {f.charAt(0).toUpperCase() + f.slice(1)}
             </button>
           ))}
        </div>

        {/* List */}
        <div className="space-y-4">
          <AnimatePresence>
            {recommendedStations.length === 0 ? (
               <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
                 <div className="w-16 h-16 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-500 mb-2">
                   <Filter size={24} />
                 </div>
                 <div>
                   <h3 className="text-lg font-bold">No chargers found</h3>
                   <p className="text-zinc-500 text-sm mt-1 max-w-[250px]">
                     We couldn't find compatible stations within {rangeLimit}km.
                   </p>
                 </div>
                 <div className="flex flex-col gap-2 w-full max-w-xs pt-4">
                   <Link href="/home">
                     <Button variant="outline" className="w-full border-zinc-700 hover:bg-zinc-800">
                       Increase Range
                     </Button>
                   </Link>
                   <Button variant="ghost" className="text-zinc-500">
                     Check Filters
                   </Button>
                 </div>
               </div>
            ) : (
              recommendedStations.map((station, idx) => (
                <motion.div
                  key={station.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <div className="glass-card p-0 overflow-hidden group">
                    {/* Badge for Top Pick */}
                    {idx === 0 && (
                      <div className="bg-primary text-black text-[10px] font-bold px-3 py-1 inline-flex items-center gap-1">
                        <Star size={10} fill="black" /> TOP RECOMMENDATION
                      </div>
                    )}

                    <div className="p-5">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                           <h3 className="font-bold text-lg leading-tight mb-1 group-hover:text-primary transition-colors">{station.name}</h3>
                           <p className="text-xs text-zinc-400 truncate max-w-[200px]">{station.address}</p>
                        </div>
                        <div className="flex flex-col items-end">
                           <span className="text-2xl font-mono font-bold">{station.distance_km}<span className="text-sm text-zinc-500 font-sans">km</span></span>
                        </div>
                      </div>

                      {/* Stats Grid */}
                      <div className="grid grid-cols-3 gap-2 py-4 border-t border-white/5 border-b mb-4 mt-2">
                         <div className="text-center border-r border-white/5">
                           <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1">Queue</div>
                           <div className={cn("font-bold", station.queue_wait_minutes > 0 ? "text-orange-500" : "text-green-500")}>
                             {station.queue_wait_minutes}m
                           </div>
                         </div>
                         <div className="text-center border-r border-white/5">
                           <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1">Charge</div>
                           <div className="font-bold text-white">~{station.estimated_charge_time}m</div>
                         </div>
                         <div className="text-center">
                           <div className="text-[10px] text-zinc-500 uppercase tracking-wider mb-1">Power</div>
                           <div className="font-bold text-primary">{station.charger_power_kw}kW</div>
                         </div>
                      </div>

                      {/* Footer Actions */}
                      <div className="flex justify-between items-center">
                         <div className="text-xs text-zinc-400">
                           <span className="text-white font-bold">₹{station.price_per_unit}</span> /unit
                         </div>
                         <Button size="sm" className="bg-white text-black hover:bg-zinc-200 rounded-full h-9 px-5 font-bold"
                           onClick={() => {
                             window.open(`https://www.google.com/maps/dir/?api=1&destination=${station.latitude},${station.longitude}`, '_blank');
                           }} 
                         >
                           <Navigation size={14} className="mr-2" /> Navigate
                         </Button>
                      </div>
                    </div>
                    
                    {/* Availability Bar - Green is fine for 'Available' status semantically, but user asked for orange accents. 
                        Let's keep status colors standard (Green/Red) but make sure highlights are orange. */}
                    <div className={cn(
                      "h-1 w-full",
                      station.status === 'available' ? "bg-green-500" : 
                      station.status === 'busy' ? "bg-orange-500" : "bg-red-500"
                    )} />
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
    </MobileLayout>
  );
}
