import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Login from "@/pages/Login";
import VehicleSelect from "@/pages/VehicleSelect";
import Home from "@/pages/Home";
import Recommendations from "@/pages/Recommendations";
import Session from "@/pages/Session";
import Analytics from "@/pages/Analytics";
import MapPage from "@/pages/MapPage";
import Profile from "@/pages/Profile";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      <Route path="/vehicles" component={VehicleSelect} />
      <Route path="/home" component={Home} />
      <Route path="/recommendations" component={Recommendations} />
      <Route path="/session" component={Session} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/map" component={MapPage} />
      <Route path="/profile" component={Profile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster />
      <Router />
    </QueryClientProvider>
  );
}

export default App;
