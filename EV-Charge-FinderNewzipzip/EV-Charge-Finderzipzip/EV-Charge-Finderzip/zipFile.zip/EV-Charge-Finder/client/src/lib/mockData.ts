import scooterImage from '@assets/generated_images/ather_450x_electric_scooter_side_profile.png';
import bikeImage from '@assets/generated_images/futuristic_black_electric_motorbike_side_profile.png';

export interface Vehicle {
  id: string;
  name: string;
  type: 'scooter' | 'bike' | 'car';
  brand: string;
  battery_capacity_kwh: number;
  full_range_km: number;
  charging_speed_kw: number;
  charger_type_supported: ('AC' | 'DC')[];
  connector_type: 'Type 2' | 'CCS2' | 'Ather Grid' | 'Bharat AC001';
  image_url: string;
  brand_logo_url?: string;
}

export interface Station {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  charger_power_kw: number;
  charger_type: 'AC' | 'DC';
  connector_type: 'Type 2' | 'CCS2' | 'Ather Grid' | 'Bharat AC001';
  price_per_unit: number;
  status: 'available' | 'busy' | 'offline';
  reliability_score: number; // 0-100
  queue_wait_minutes: number;
  distance_km?: number; // Calculated at runtime
}

// Comprehensive Indian EV List
export const MOCK_VEHICLES: Vehicle[] = [
  // --- ELECTRIC SCOOTERS ---
  {
    id: 's_ather_450x',
    name: '450X',
    brand: 'Ather',
    type: 'scooter',
    battery_capacity_kwh: 3.7,
    full_range_km: 150,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'Ather Grid',
    image_url: scooterImage
  },
  {
    id: 's_ather_450s',
    name: '450S',
    brand: 'Ather',
    type: 'scooter',
    battery_capacity_kwh: 2.9,
    full_range_km: 115,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'Ather Grid',
    image_url: scooterImage
  },
  {
    id: 's_ola_s1_pro',
    name: 'S1 Pro Gen 2',
    brand: 'Ola',
    type: 'scooter',
    battery_capacity_kwh: 4.0,
    full_range_km: 195,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_ola_s1_air',
    name: 'S1 Air',
    brand: 'Ola',
    type: 'scooter',
    battery_capacity_kwh: 3.0,
    full_range_km: 151,
    charging_speed_kw: 2.2,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_ola_s1',
    name: 'S1 X',
    brand: 'Ola',
    type: 'scooter',
    battery_capacity_kwh: 3.0,
    full_range_km: 151,
    charging_speed_kw: 2.2,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_tvs_iqube',
    name: 'iQube',
    brand: 'TVS',
    type: 'scooter',
    battery_capacity_kwh: 3.04,
    full_range_km: 100,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_tvs_iqube_s',
    name: 'iQube S',
    brand: 'TVS',
    type: 'scooter',
    battery_capacity_kwh: 3.4,
    full_range_km: 100,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_tvs_iqube_st',
    name: 'iQube ST',
    brand: 'TVS',
    type: 'scooter',
    battery_capacity_kwh: 5.1,
    full_range_km: 145,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_bajaj_chetak',
    name: 'Chetak Premium',
    brand: 'Bajaj',
    type: 'scooter',
    battery_capacity_kwh: 3.2,
    full_range_km: 126,
    charging_speed_kw: 1.2,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_hero_vida_v1_pro',
    name: 'Vida V1 Pro',
    brand: 'Hero',
    type: 'scooter',
    battery_capacity_kwh: 3.94,
    full_range_km: 165,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'Ather Grid',
    image_url: scooterImage
  },
  {
    id: 's_hero_vida_v1_plus',
    name: 'Vida V1 Plus',
    brand: 'Hero',
    type: 'scooter',
    battery_capacity_kwh: 3.44,
    full_range_km: 143,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'Ather Grid',
    image_url: scooterImage
  },
  {
    id: 's_simple_one',
    name: 'Simple One',
    brand: 'Simple Energy',
    type: 'scooter',
    battery_capacity_kwh: 5.0,
    full_range_km: 212,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_ampere_primus',
    name: 'Primus',
    brand: 'Ampere',
    type: 'scooter',
    battery_capacity_kwh: 3.0,
    full_range_km: 107,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_ampere_magnus',
    name: 'Magnus EX',
    brand: 'Ampere',
    type: 'scooter',
    battery_capacity_kwh: 2.3,
    full_range_km: 121,
    charging_speed_kw: 1.0,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_okinawa_ipraise',
    name: 'iPraise+',
    brand: 'Okinawa',
    type: 'scooter',
    battery_capacity_kwh: 3.3,
    full_range_km: 139,
    charging_speed_kw: 1.0,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_okinawa_okhi90',
    name: 'Okhi90',
    brand: 'Okinawa',
    type: 'scooter',
    battery_capacity_kwh: 3.6,
    full_range_km: 160,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_bounce_infinity',
    name: 'Infinity E1',
    brand: 'Bounce',
    type: 'scooter',
    battery_capacity_kwh: 1.9,
    full_range_km: 85,
    charging_speed_kw: 1.0,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },
  {
    id: 's_river_indie',
    name: 'Indie',
    brand: 'River',
    type: 'scooter',
    battery_capacity_kwh: 4.0,
    full_range_km: 120,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: scooterImage
  },

  // --- ELECTRIC MOTORCYCLES ---
  {
    id: 'm_uv_f77',
    name: 'F77',
    brand: 'Ultraviolette',
    type: 'bike',
    battery_capacity_kwh: 7.1,
    full_range_km: 206,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: bikeImage
  },
  {
    id: 'm_uv_f77_recon',
    name: 'F77 Recon',
    brand: 'Ultraviolette',
    type: 'bike',
    battery_capacity_kwh: 10.3,
    full_range_km: 323,
    charging_speed_kw: 7.2,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: bikeImage
  },
  {
    id: 'm_revolt_rv400',
    name: 'RV400',
    brand: 'Revolt',
    type: 'bike',
    battery_capacity_kwh: 3.24,
    full_range_km: 150,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: bikeImage
  },
  {
    id: 'm_revolt_rv1',
    name: 'RV1',
    brand: 'Revolt',
    type: 'bike',
    battery_capacity_kwh: 2.2,
    full_range_km: 100,
    charging_speed_kw: 1.0,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: bikeImage
  },
  {
    id: 'm_tork_kratos',
    name: 'Kratos',
    brand: 'Tork',
    type: 'bike',
    battery_capacity_kwh: 4.0,
    full_range_km: 180,
    charging_speed_kw: 2.2,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: bikeImage
  },
  {
    id: 'm_tork_kratos_r',
    name: 'Kratos R',
    brand: 'Tork',
    type: 'bike',
    battery_capacity_kwh: 4.0,
    full_range_km: 180,
    charging_speed_kw: 2.2,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: bikeImage
  },
  {
    id: 'm_oben_rorr',
    name: 'Rorr',
    brand: 'Oben',
    type: 'bike',
    battery_capacity_kwh: 4.4,
    full_range_km: 187,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: bikeImage
  },
  {
    id: 'm_matter_aera',
    name: 'Aera',
    brand: 'Matter',
    type: 'bike',
    battery_capacity_kwh: 5.0,
    full_range_km: 125,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: bikeImage
  },
  {
    id: 'm_joy_beast',
    name: 'Beast',
    brand: 'Joy e-bike',
    type: 'bike',
    battery_capacity_kwh: 5.4,
    full_range_km: 110,
    charging_speed_kw: 1.5,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: bikeImage
  },

  // --- ELECTRIC CARS ---
  {
    id: 'c_tata_nexon_ev_mr',
    name: 'Nexon EV MR',
    brand: 'Tata',
    type: 'car',
    battery_capacity_kwh: 30.2,
    full_range_km: 325,
    charging_speed_kw: 30,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_tata_nexon_ev_lr',
    name: 'Nexon EV LR',
    brand: 'Tata',
    type: 'car',
    battery_capacity_kwh: 40.5,
    full_range_km: 465,
    charging_speed_kw: 50,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_tata_nexon_ev_max',
    name: 'Nexon EV Max',
    brand: 'Tata',
    type: 'car',
    battery_capacity_kwh: 40.5,
    full_range_km: 453,
    charging_speed_kw: 50,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_tata_punch_ev',
    name: 'Punch EV',
    brand: 'Tata',
    type: 'car',
    battery_capacity_kwh: 35.0,
    full_range_km: 421,
    charging_speed_kw: 50,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_tata_tiago_ev',
    name: 'Tiago EV',
    brand: 'Tata',
    type: 'car',
    battery_capacity_kwh: 24.0,
    full_range_km: 315,
    charging_speed_kw: 25,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_tata_tigor_ev',
    name: 'Tigor EV',
    brand: 'Tata',
    type: 'car',
    battery_capacity_kwh: 26.0,
    full_range_km: 315,
    charging_speed_kw: 25,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_mg_zs_ev',
    name: 'ZS EV',
    brand: 'MG',
    type: 'car',
    battery_capacity_kwh: 50.3,
    full_range_km: 461,
    charging_speed_kw: 50,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_mg_comet_ev',
    name: 'Comet EV',
    brand: 'MG',
    type: 'car',
    battery_capacity_kwh: 17.3,
    full_range_km: 230,
    charging_speed_kw: 3.3,
    charger_type_supported: ['AC'],
    connector_type: 'Type 2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_mahindra_xuv400',
    name: 'XUV400',
    brand: 'Mahindra',
    type: 'car',
    battery_capacity_kwh: 39.4,
    full_range_km: 456,
    charging_speed_kw: 50,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_hyundai_kona',
    name: 'Kona Electric',
    brand: 'Hyundai',
    type: 'car',
    battery_capacity_kwh: 39.2,
    full_range_km: 452,
    charging_speed_kw: 50,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_hyundai_ioniq_5',
    name: 'Ioniq 5',
    brand: 'Hyundai',
    type: 'car',
    battery_capacity_kwh: 72.6,
    full_range_km: 631,
    charging_speed_kw: 350,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_citroen_ec3',
    name: 'ë-C3',
    brand: 'Citroën',
    type: 'car',
    battery_capacity_kwh: 29.2,
    full_range_km: 320,
    charging_speed_kw: 30,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_byd_atto_3',
    name: 'Atto 3',
    brand: 'BYD',
    type: 'car',
    battery_capacity_kwh: 60.48,
    full_range_km: 521,
    charging_speed_kw: 80,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_byd_seal',
    name: 'Seal',
    brand: 'BYD',
    type: 'car',
    battery_capacity_kwh: 82.5,
    full_range_km: 650,
    charging_speed_kw: 150,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_bmw_i4',
    name: 'i4',
    brand: 'BMW',
    type: 'car',
    battery_capacity_kwh: 83.9,
    full_range_km: 590,
    charging_speed_kw: 205,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_bmw_ix',
    name: 'iX',
    brand: 'BMW',
    type: 'car',
    battery_capacity_kwh: 76.6,
    full_range_km: 425,
    charging_speed_kw: 150,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_kia_ev6',
    name: 'EV6',
    brand: 'Kia',
    type: 'car',
    battery_capacity_kwh: 77.4,
    full_range_km: 708,
    charging_speed_kw: 350,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  },
  {
    id: 'c_volvo_xc40',
    name: 'XC40 Recharge',
    brand: 'Volvo',
    type: 'car',
    battery_capacity_kwh: 78.0,
    full_range_km: 418,
    charging_speed_kw: 150,
    charger_type_supported: ['AC', 'DC'],
    connector_type: 'CCS2',
    image_url: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=1000'
  }
];

// Centered around Chennai (Guindy area roughly) for demo
const BASE_LAT = 13.0067;
const BASE_LNG = 80.2206;

export const MOCK_STATIONS: Station[] = [
  {
    id: 's1',
    name: 'Ather Grid - Phoenix Marketcity',
    address: 'Velachery Main Rd, Chennai',
    latitude: BASE_LAT + 0.01,
    longitude: BASE_LNG + 0.01,
    charger_power_kw: 3.3,
    charger_type: 'DC',
    connector_type: 'Ather Grid',
    price_per_unit: 15,
    status: 'available',
    reliability_score: 98,
    queue_wait_minutes: 0
  },
  {
    id: 's2',
    name: 'Zeon Charging Station',
    address: 'Grand Galada Centre, Guindy',
    latitude: BASE_LAT - 0.005,
    longitude: BASE_LNG - 0.005,
    charger_power_kw: 50,
    charger_type: 'DC',
    connector_type: 'CCS2',
    price_per_unit: 22,
    status: 'busy',
    reliability_score: 92,
    queue_wait_minutes: 15
  },
  {
    id: 's3',
    name: 'Tata Power EZ Charge',
    address: 'Anna Salai, Little Mount',
    latitude: BASE_LAT + 0.02,
    longitude: BASE_LNG - 0.01,
    charger_power_kw: 25,
    charger_type: 'DC',
    connector_type: 'CCS2',
    price_per_unit: 18,
    status: 'available',
    reliability_score: 85,
    queue_wait_minutes: 0
  },
  {
    id: 's4',
    name: 'Shell Recharge',
    address: 'OMR, Thoraipakkam',
    latitude: BASE_LAT - 0.04,
    longitude: BASE_LNG + 0.03,
    charger_power_kw: 60,
    charger_type: 'DC',
    connector_type: 'CCS2',
    price_per_unit: 24,
    status: 'available',
    reliability_score: 99,
    queue_wait_minutes: 0
  },
  {
    id: 's5',
    name: 'Relux Electric',
    address: 'Mount Road, Saidapet',
    latitude: BASE_LAT + 0.015,
    longitude: BASE_LNG + 0.005,
    charger_power_kw: 7.2,
    charger_type: 'AC',
    connector_type: 'Type 2',
    price_per_unit: 12,
    status: 'offline',
    reliability_score: 60,
    queue_wait_minutes: 0
  },
  {
    id: 's6',
    name: 'Statiq Charging Station',
    address: 'T Nagar, Chennai',
    latitude: BASE_LAT + 0.03,
    longitude: BASE_LNG - 0.02,
    charger_power_kw: 30,
    charger_type: 'DC',
    connector_type: 'CCS2',
    price_per_unit: 20,
    status: 'available',
    reliability_score: 88,
    queue_wait_minutes: 0
  },
  {
    id: 's7',
    name: 'ChargeZone',
    address: 'Chromepet, Chennai',
    latitude: BASE_LAT - 0.06,
    longitude: BASE_LNG - 0.02,
    charger_power_kw: 60,
    charger_type: 'DC',
    connector_type: 'CCS2',
    price_per_unit: 21,
    status: 'available',
    reliability_score: 95,
    queue_wait_minutes: 0
  }
];

export const haversineDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return Number(d.toFixed(1));
};

function deg2rad(deg: number) {
  return deg * (Math.PI / 180);
}

export const calculateChargeTime = (
  currentSoc: number, 
  targetSoc: number, 
  batteryKwh: number, 
  chargerPowerKw: number
) => {
  if (currentSoc >= targetSoc) return 0;
  const neededKwh = ((targetSoc - currentSoc) / 100) * batteryKwh;
  // Simple formula: kWh needed / kW power * 60 mins
  // In reality, charging curves slow down past 80%, but for MVP this is fine.
  return Math.ceil((neededKwh / chargerPowerKw) * 60);
};
